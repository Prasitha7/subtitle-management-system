import { useEffect, useState } from "react";
import { fetchMedia } from "../api/mediaApi";
import styles from "./Page.module.css";
import AddMediaModal from "../components/AddMedia/AddMedia.jsx";

function Media({ token }) {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddMedia, setShowAddMedia] = useState(false);

  useEffect(() => {
    setLoading(true);
    setError(null);

    fetchMedia(token)
      .then(data => {
        setMovies(data.filter(m => m.type === "MOVIE"));
      })
      .catch(err => {
        setError(err.message);
      })
      .finally(() => setLoading(false));
  }, [token]);

  if (loading) {
    return <p>⏳ Loading movies...</p>;
  }

  if (error) {
    return <p style={{ color: "red" }}>❌ Error: {error}</p>;
  }

  return (
    <div className={styles.page}>
      {/* 🔘 HEADER BAR */}
      <div className={styles.headerBar}>
        <h2>🎬 Movies</h2>

        {token && (
          <button onClick={() => setShowAddMedia(true)}>
            + Add Media
          </button>
        )}
      </div>

      {/* 📋 EMPTY STATE */}
      {movies.length === 0 && (
        <p className={styles.empty}>No movies found.</p>
      )}

      {/* 📋 TABLE */}
      {movies.length > 0 && (
        <table
          className={styles.table}
          border="1"
          cellPadding="10"
          style={{ borderCollapse: "collapse" }}
        >
          <thead style={{ backgroundColor: "#f5f5f5" }}>
            <tr>
              <th>Title</th>
              <th>Type</th>
              <th>Release Date</th>
            </tr>
          </thead>
          <tbody>
            {movies.map(movie => (
              <tr key={movie.id}>
                <td>{movie.title}</td>
                <td>{movie.type}</td>
                <td>
                  {movie.releaseDate
                    ? new Date(movie.releaseDate).toLocaleDateString()
                    : "Not released"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* 🪟 ADD MEDIA MODAL */}
      {showAddMedia && (
        <AddMediaModal
          token={token}
          onClose={() => setShowAddMedia(false)}
        />
      )}
    </div>
  );
}

export default Media;
