import styles from "./Page.module.css";

function Home(){
    return(
        <h1 className={styles.page}
        >Home Page</h1>
    )
}
export default Home;