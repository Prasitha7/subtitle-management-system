function Publisher(){
    return(
        <h1>Publisher Page</h1>
    )
}
export default Publisher;