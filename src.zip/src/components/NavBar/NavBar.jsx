import {Link} from "react-router-dom";
import styles from "./NavBar.module.css"

function NavBar({ token, onLoginClick }) {
  return (
    <nav className={styles.navbar}>
      {/* LEFT */}
      <ul className={styles.left}>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/media">Media</Link></li>
        <li><Link to="/publishers">Publishers</Link></li>

        {token && (
          <li><Link to="/my-media">My Media</Link></li>
        )}
      </ul>

      {/* RIGHT */}
      <div className={styles.right}>
        {!token ? (
          <button onClick={onLoginClick}>Login</button>
        ) : (
          <div className={styles.profile}>
            👤 User
          </div>
        )}
      </div>
    </nav>
  );
}

export default NavBar;